package com.xiaozhu.com.xiaozhu.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * @author hrd <br/>
 * @date 2021/9/22
 */
@Api(tags = "微信模块")
@RestController
@RequestMapping("/wx")
public class WeiXinController {

    @Autowired
    private HttpServletRequest request;

    @ApiOperation("发送外卖红包")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "platform", required = true, value = "平台: 1 美团 2 饿了么", dataType = "int", paramType = "query")
    })
    @GetMapping("/sendTakeOutMessage")
    public void sendTakeOutMessage(@RequestParam int platform){

    }

}
