package com.xiaozhu.com.xiaozhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XiaozhuApplication {

    public static void main(String[] args) {
        SpringApplication.run(XiaozhuApplication.class, args);
    }

}
