package com.xiaozhu.com.xiaozhu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XiaozhuApplicationTests {

    @Test
    void contextLoads() {
    }

}
